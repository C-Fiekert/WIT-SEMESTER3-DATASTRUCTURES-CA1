///Packages///
package Theatre;

///Imports///
import java.util.Date;
import static Theatre.Show.fullts;

///Performance Class///
public class Performance {
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //FIELDS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Performance attributes
    private Date performanceDate;
    private boolean matinee, evening;
    //Each performance may have many bookings
    private LinkedList<Booking> bookings = new LinkedList<>();
    //Seat area arrays
    public static Seat[] balcony = new Seat[24];
    public static Seat[] circle = new Seat[30];
    public static Seat[] stall = new Seat[40];

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //CONSTRUCTOR//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Parameters needed to create a new performance
    public Performance(Date performance, boolean matinee, boolean evening) {
        this.performanceDate = performance;
        this.matinee = matinee;
        this.evening = evening;
        for(int i = 0; i < 24; i++){
            this.balcony[i] = new Seat("B"+(i+1), false);
        }
        for(int i = 0; i < 24; i++){
            this.circle[i] = new Seat("C"+(i+1), false);
        }
        for(int i = 0; i < 24; i++){
            this.stall[i] = new Seat("S"+(i+1), false);
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //METHODS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Performance toString///
    //Confirms performance is being added to Performance list
    @Override
    public String toString() {
        if (fullts) {
            return "Performance{" +
                    "Performance Date = " + performanceDate +
                    ", Takes place during matinee = " + matinee +
                    ", Takes place during evening = " + evening +
                    '}';
        }
        return performanceDate.toString();
    }

    ///Get Performance Date///
    public Date getPerformance() {
        return performanceDate;
    }

    ///Get Booking list///
    public LinkedList<Booking> getBookings() {
        return bookings;
    }

    ///Add Booking to Performance///
    public void addBooking(Booking book) {
        bookings.addElement(book);
    }

    ///Find Seats method///
    public Seat[] findSeats(int area, int number){
        //If in balcony
        if (area == 1){
            //Create an array to fit the number of selected seats
            Seat[] tempArray = new Seat[number];
            int seats = 0;
            for (int i=0;i<balcony.length;i++){
                if (balcony[i].isBooked() == false){
                    //Adds available seats to the array
                    tempArray[seats]=balcony[i];
                    seats++;
                }
                //Once every seat is gotten, return array
                if (seats == number){
                    return tempArray;
                }
            }
            System.out.println(tempArray.toString());
        }
        //If in circle
        else if (area == 2){
            //Create an array to fit the number of selected seats
            Seat[] tempArray = new Seat[number];
            int seats = 0;
            for (int i=0;i<circle.length;i++){
                if (circle[i].isBooked() == false){
                    //Adds available seats to the array
                    tempArray[seats]=circle[i];
                    seats++;
                }
                //Once every seat is gotten, return array
                if (seats == number){
                    return tempArray;
                }
            }
            System.out.println(tempArray.toString());
        }
        //If in stall
        else if (area == 3){
            //Create an array to fit the number of selected seats
            Seat[] tempArray = new Seat[number];
            int seats = 0;
            for (int i=0;i<stall.length;i++){
                if (stall[i].isBooked() == false){
                    //Adds available seats to the array
                    tempArray[seats]=stall[i];
                    seats++;
                }
                //Once every seat is gotten, return array
                if (seats == number){
                    return tempArray;
                }
            }
            System.out.println(tempArray.toString());
        }
        return null;
    }

    ///Get booking method///
    public Booking[] getBooking() {
        Booking []  tempP= new Booking[bookings.numElements];
        Object[] tempO = bookings.toArray();
        for(int i = 0; i<tempP.length;i++){
            tempP[i] = (Booking) tempO[i];
        }
        //Returns an array of bookings for a performance
        return tempP;
    }
}

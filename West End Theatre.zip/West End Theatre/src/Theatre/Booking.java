///Packages///
package Theatre;

///Booking Class///
public class Booking {
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //FIELDS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Customer info
    private String customerName, seat;
    //Seat info
    private int numSeats, seatArea;
    //Booking for show
    private Show parent;
    //Booking for performance
    private Performance date;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //CONSTRUCTOR//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Parameters needed to create a new booking
    public Booking(String customerName, String seat, int numSeats, int seatArea, Show parent, Performance date){
        this.customerName=customerName;
        this.seat=seat;
        this.numSeats=numSeats;
        this.seatArea=seatArea;
        this.parent=parent;
        this.date=date;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //METHODS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Booking toString///
    //Confirms booking is being added to Booking list
    @Override
    public String toString() {
        return "Booking{" +
                "Customer Name = " + customerName +
                ", Seats = " + seat +
                '}';
    }

    ///Get customer name///
    public String getCustomerName() {
        return customerName;
    }

    ///Get Seats///
    public String getSeat() {
        return seat;
    }

    ///Get number of seats///
    public int getNumSeats() {
        return numSeats;
    }

    ///Get seat area///
    public int getSeatArea() {
        return seatArea;
    }

    ///Get booking's show///
    public Show getParent() {
        return parent;
    }

    ///Get booking's performance///
    public Performance getDate() {
        return date;
    }
}
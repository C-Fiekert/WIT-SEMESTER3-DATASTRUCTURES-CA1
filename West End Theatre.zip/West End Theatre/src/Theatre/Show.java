///Packages///
package Theatre;

///Imports///
import java.util.Date;

///Show Class///
public class Show {
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //FIELDS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Show attributes
    private String showName;
    private int showRunningTime, balconyP, circleP, stallsP;
    private Date startDate, endDate;
    //Each show may have many performances
    private LinkedList<Performance> performances = new LinkedList<>();
    //toString flag
    public static boolean fullts=true;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //CONSTRUCTOR//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Parameters needed to create a new show
    public Show(String name, int runningTime, Date startDate, Date endDate, int balconyP, int circleP, int stallsP) {
        this.showName = name;
        this.showRunningTime = runningTime;
        this.startDate = startDate;
        this.endDate = endDate;
        this.balconyP = balconyP;
        this.circleP = circleP;
        this.stallsP = stallsP;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //METHODS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Show toString///
    //Confirms show is being added to Show list
    @Override
    public String toString() {
        if(fullts) {
            return "Show{" +
                    "Show Name = '" + showName +
                    ", Balcony Price = €" + balconyP +
                    ", Circle Price = €" + circleP +
                    ", Stall Price = €" + stallsP +
                    ", Show Run Time = " + showRunningTime +
                    ", Start Date = " + startDate +
                    ", End Date = " + endDate +
                    '}';
        }
        return showName;
    }

    ///Get Show Name///
    public String getShowName() {
        return showName;
    }

    ///Get Balcony Price///
    public int getBalconyP() {
        return balconyP;
    }

    ///Get Circle Price///
    public int getCircleP() {
        return circleP;
    }

    ///Get Stalls Price///
    public int getStallsP() {
        return stallsP;
    }

    ///Gets Perfs list///
    public LinkedList<Performance> getPerfs() {
        return performances;
    }

    ///Get Performance lists
    public Performance[] getPerformances() {
        Performance []  tempP= new Performance[performances.numElements];
        Object[] tempO = performances.toArray();
        for(int i = 0; i<tempP.length;i++){
            tempP[i] = (Performance) tempO[i];
        }
        return tempP;
    }

    ///Add Performance to Show///
    public void addPerformance(Performance perf){
        performances.addElement(perf);
    }
}

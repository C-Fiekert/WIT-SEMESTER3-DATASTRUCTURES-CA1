///Packages///
package Theatre;

///Imports///
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;

///Alertbox Class
public class Alertbox {
    //Alertbox method
    public static void alert(String title, String head, String message){
        Alert popup = new Alert(Alert.AlertType.INFORMATION);
        //Must be clicked to continue
        popup.initModality(Modality.APPLICATION_MODAL);
        popup.setTitle(title);
        popup.setHeaderText(head);
        popup.setContentText(message);
        //Layout and positioning
        VBox layout = new VBox(30);
        layout.setAlignment(Pos.CENTER);
        popup.showAndWait();
    }
}
///Packages///
package Theatre;

///Imports///
//Javafx
import javafx.fxml.FXML;
import javafx.scene.control.*;
//Xstream Save/Load
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
//toString flag
import static Theatre.Show.fullts;

///Controller Class///
public class Controller {
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            //FIELDS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Shows list
    LinkedList<Show> shows = new LinkedList<>();
    //Public integers
    int m, number;
    //Stores selected show
    Show theShow;
    //Stores selected performance
    Performance thePerf;
    //Seat array
    Seat[] selection;
    //Shows array
    Object[] showsArray = shows.toArray();
    //TabPane identity
    @FXML
    TabPane tabPane;
    //Tab identities
    @FXML
    Tab addShowTab, addPerfTab, addBookTab, viewFac, cancelTab, resetTab;
    //Entered strings
    @FXML
    TextField txtShowName, txtRunTime, txtBalconyP, txtCircleP, txtStallsP, customerName, seat;
    //Entered dates
    @FXML
    DatePicker startDate, endDate, perfDate;
    //Times of day selected
    @FXML
    CheckBox matinee, evening;
    //All program dropdowns
    @FXML
    ChoiceBox selectShow1, selectShow2, selectShow3, selectShow4, selectShow5, selectPerformance1, selectPerformance2, selectPerformance3, selectBooking1, area, pickNumber;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //SHOW//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Add Show Method///
    public void addShow() throws Exception {
            //Creates show with all of its parameters
            Show newShow = new Show(txtShowName.getText(), Integer.parseInt(txtRunTime.getText()), java.sql.Timestamp.valueOf(startDate.getValue().atTime(0, 0, 0, 0)), java.sql.Timestamp.valueOf(endDate.getValue().atTime(0, 0, 0, 0)), Integer.parseInt(txtBalconyP.getText()), Integer.parseInt(txtCircleP.getText()), Integer.parseInt(txtStallsP.getText()));
            //Adds show to Show list
            shows.addElement(newShow);
            fullts = true;
            //Shows all shows and their contents in the event log
            System.out.println(shows.listElementContents());
            //Populates dropdowns with each show name
            populateShow();
            //Shows Alert box
            Alertbox.alert("West End Theatre", "Show has Been added!", "Thank You!");
            //Enables tabs
            addPerfTab.setDisable(false);
            cancelTab.setDisable(false);
            resetTab.setDisable(false);
    }

    ///Delete show method///
    public void deleteShow(){
        //Gets and deletes selected show
        shows.deleteElement(selectShow4.getSelectionModel().getSelectedIndex());
        //Repopulates the dropdowns
        populateShow();
        //Prints to event log
        System.out.println("Show has been deleted!");
        //Delete show Alert box
        Alertbox.alert("West End Theatre", "Show has been deleted", "Click ok to continue");
    }

    ///Find show by index method///
    public Show getShowByIndex(int index){
        //Cycle through the shows list
        for (m = 0; m < shows.numElements; m++) {
            //If the selected show index matches a shows index in the array ...
            if (shows.getElement(m).equals(showsArray[index])){
                //Return the show object
                return (Show) shows.getElement(m);
            }
        }
        theShow = (Show) shows.getElement(m);
        //Passes back the show
        return theShow;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //PERFORMANCE//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Add Performance Method///
    public void addPerformance() {
            //Creates a performance with all of its parameter
            Performance newPerf = new Performance(java.sql.Timestamp.valueOf(perfDate.getValue().atTime(0, 0, 0, 0)), matinee.isSelected(), evening.isSelected());
            //Uses the show returned by the getShowByIndex method
            Show newShow = getShowByIndex(selectShow1.getSelectionModel().getSelectedIndex());
            //Adds the new performance to the show
            newShow.addPerformance(newPerf);
            fullts = true;
            //Shows all shows and their performances in the event log
            System.out.println("Show Name = " + (newShow.getShowName()));
            System.out.println(newShow.getPerfs().listElementContents());
            //Shows Alert box
            Alertbox.alert("West End Theatre", "Performance has Been added!", "Thank You!");
            //Enables add booking tab
            addBookTab.setDisable(false);
    }

    ///Delete Performance method///
    public void deletePerformance(){
        //Gets selected show
        Show newShow = getShowByIndex(selectShow5.getSelectionModel().getSelectedIndex());
        //Gets and deletes selected performance
        newShow.getPerfs().deleteElement(selectPerformance3.getSelectionModel().getSelectedIndex());
        //Prints to event log
        System.out.println("Performance has been deleted!");
        //Delete performance Alert box
        Alertbox.alert("West End Theatre", "Performance has been deleted", "Click ok to continue");
    }

    ///Find performance by index method///
    public Performance getPerformanceByIndex(int index){
        Object[] thePerfs = (theShow.getPerfs().toArray());

        return (Performance) thePerfs[index];
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                    //BOOKING//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///Add Booking Method///
    public void addBooking() {
        //Creates a booking with all of its parameters
        Booking newBook = new Booking(customerName.getText(), seat.getText(), pickNumber.getSelectionModel().getSelectedIndex(), area.getSelectionModel().getSelectedIndex(), (Show) selectShow2.getValue(), (Performance) selectPerformance1.getValue());
        //Uses the performance returned by the getPerformanceByIndex method
        Performance newPerf = getPerformanceByIndex(selectPerformance1.getSelectionModel().getSelectedIndex());
        //Adds the new booking to the performance
        newPerf.addBooking(newBook);
        for (int i=0; i<selection.length;i++){
            //Make the booked seats not available
            selection[i].setBooked(true);
        }
        //Shows all bookings of a performance for a show in the event log
        System.out.println(newPerf.toString());
        System.out.println(newPerf.getBookings().listElementContents());
        //Bookings Alert box
        Alertbox.alert("West End Theatre", "Booking has been added!", "Thank You " + newBook.getCustomerName() + "!\n" + "We hope you enjoy the performance!");
        //Enables view facilities tab
        viewFac.setDisable(false);
    }

    ///Find Booking by index method///
    public Booking getBookingByIndex(int index){
        Object[] theBooks = (thePerf.getBookings().toArray());

        return (Booking) theBooks[index];
    }

    ///Get seats method///
    public void getSeats(){
        //Gets selected area
        int section = area.getSelectionModel().getSelectedIndex()+1;
        //Gets selected number of seats
        number = pickNumber.getSelectionModel().getSelectedIndex()+1;
        //Gets selected performance
        Performance newPerf = getPerformanceByIndex(selectPerformance1.getSelectionModel().getSelectedIndex());
        //Finds available seats in area
        selection = newPerf.findSeats(section, number);
        //Creates a string of seats
        String mySeats="";
        for(int i =0;i<selection.length;i++){
            //Adds available seat to string
            mySeats += selection[i].getSeatNumber() + " ";
        }
        //Displays available seats
        seat.setText(mySeats);
    }

    ///Calculate booking price method///
    public int bookingPrice(){
        //Gets selected booking
        Booking newBook = getBookingByIndex(selectBooking1.getSelectionModel().getSelectedIndex());
        //Gets number of seats for booking
        int numSeats = newBook.getNumSeats()+1;
        //Total circle price
        if (newBook.getSeatArea() == 1) {
            number = numSeats*newBook.getParent().getCircleP();
        }
        //Total stall price
        else if (newBook.getSeatArea() == 2) {
            number = numSeats*newBook.getParent().getStallsP();
        }
        //Total balcony price
        else {
            number = numSeats*newBook.getParent().getBalconyP();
        }
        //Returns booking price
        return number;
    }

    ///Show receipt method///
    public void listReceipt(){
        //Gets selected booking
        Booking newBook = getBookingByIndex(selectBooking1.getSelectionModel().getSelectedIndex());
        //Shows booking's receipt
        Alertbox.alert("Receipt", "Show Name: " + newBook.getParent().getShowName() + "\n\n" + "Show Date: " + newBook.getDate().getPerformance() + "\n\n" + "Customer Name: " + newBook.getCustomerName() + "\n\n" + "Seats:  " + newBook.getSeat(), "Total Price: €" + bookingPrice());
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                    //POPULATE DROPDOWNS//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Populate show dropdowns///
    public void populateShow() {
        //Clears all show drop downs
        selectShow1.getItems().clear();
        selectShow2.getItems().clear();
        selectShow3.getItems().clear();
        selectShow4.getItems().clear();
        selectShow5.getItems().clear();
        //Adds all shows in list to an array
        showsArray = shows.toArray();
        //Cycles through every show in the array and adds it to the dropdowns
        for (int m = 0; m < shows.numElements; m++) {
            fullts = false;
            selectShow1.getItems().add(showsArray[m]);
            selectShow2.getItems().add(showsArray[m]);
            selectShow3.getItems().add(showsArray[m]);
            selectShow4.getItems().add(showsArray[m]);
            selectShow5.getItems().add(showsArray[m]);
        }
    }

    ///Populates dropdowns on program launch///
    public void initialize(){
        //Number of seats dropdown
        for (int i=1; i<4;i++){
            pickNumber.getItems().add(i);
        }
        //Seat area dropdown
        area.getItems().add("Balcony");
        area.getItems().add("Circle");
        area.getItems().add("Stalls");
    }

    ///Populates first performance dropdown
    public void populatePerformance1(){
        selectPerformance1.getItems().clear();
        //use the value of the choice box for show
        Show selectedShow = (Show) selectShow2.getValue();
        theShow=selectedShow;
        Performance[] perfArray;
        perfArray = selectedShow.getPerformances();
        fullts = false;
        if (perfArray.length > 0) {
            for (int i = 0; i < perfArray.length; i++) {
                selectPerformance1.getItems().add(perfArray[i]);
            }
        }
    }

    ///Populates second performance dropdown///
    public void populatePerformance2(){
        selectPerformance2.getItems().clear();
        //use the value of the choice box for show
        Show selectedShow = (Show) selectShow3.getValue();
        theShow=selectedShow;
        Performance[] perfArray;
        perfArray = selectedShow.getPerformances();
        fullts = false;
        if (perfArray.length > 0) {
            for (int i = 0; i < perfArray.length; i++) {
                selectPerformance2.getItems().add(perfArray[i]);
            }
        }
    }

    ///Populates third performance dropdown///
    public void populatePerformance3(){
        selectPerformance3.getItems().clear();
        //use the value of the choice box for show
        Show selectedShow = (Show) selectShow5.getValue();
        theShow=selectedShow;
        Performance[] perfArray;
        perfArray = selectedShow.getPerformances();
        fullts = false;
        if (perfArray.length > 0) {
            for (int i = 0; i < perfArray.length; i++) {
                selectPerformance3.getItems().add(perfArray[i].getPerformance());
            }
        }
    }

    ///Populate booking dropdown///
    public void populateBooking() {
        selectBooking1.getItems().clear();
        //use the value of the choice box for performance
        Performance selectedPerf = (Performance) selectPerformance2.getValue();
        thePerf = selectedPerf;
        Booking[] bookArray;
        bookArray = selectedPerf.getBooking();
        if (bookArray.length > 0) {
            for (int i = 0; i < bookArray.length; i++) {
                selectBooking1.getItems().add(bookArray[i].getCustomerName());
            }
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                //SAVE   LOAD   RESET//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Load shows///
    @SuppressWarnings("unchecked")
    public void load() throws Exception {
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("WestEndTheatre.xml"));
        shows = (LinkedList<Show>) is.readObject();
        is.close();
        populateShow();
        //Enables all tabs
        addPerfTab.setDisable(false);
        addBookTab.setDisable(false);
        viewFac.setDisable(false);
        cancelTab.setDisable(false);
        resetTab.setDisable(false);
    }

    ///Save shows///
    public void save() throws Exception {
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("WestEndTheatre.xml"));
        out.writeObject(shows);
        out.close();
        Alertbox.alert("West End Theatre", "System has been saved", "Click ok to continue");
    }

    ///Reset System///
    public void reset(){
        //Reset Alert box
        Alertbox.alert("Reset System", "WARNING!", "You are about to reset the system, click ok to continue");
        //Deletes all shows
        shows.head = null;
        shows.numElements = 0;
        selectShow1.getItems().clear();
        selectShow2.getItems().clear();
        selectShow3.getItems().clear();
        selectShow4.getItems().clear();
        //Print to event log
        System.out.println("System has been reset");
        //Reset successful Alert box
        Alertbox.alert("West End Theatre", "System reset successfully", "Click ok to continue");
        //Goes to add show tab
        tabPane.getSelectionModel().select(addShowTab);
        //Clears all fields
        txtShowName.clear();
        txtRunTime.clear();
        txtBalconyP.clear();
        txtCircleP.clear();
        txtStallsP.clear();
        //Disables other tabs
        addPerfTab.setDisable(true);
        addBookTab.setDisable(true);
        viewFac.setDisable(true);
        cancelTab.setDisable(true);
        resetTab.setDisable(true);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                        //EXIT//
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///Exit System///
    public void quit(){
        System.exit(0);
    }
}